# website_toolbox_php_sdk
The Website Toolbox API is organized around <a href=\"http://en.wikipedia.org/wiki/Representational_State_Transfer\">REST</a>. Our API has predictable, resource-oriented URLs, and uses HTTP response codes to indicate API errors. We use built-in HTTP features, like HTTP authentication and HTTP verbs, which are understood by off-the-shelf HTTP clients. We support <a href=\"http://en.wikipedia.org/wiki/Cross-origin_resource_sharing\">cross-origin resource sharing</a>, allowing you to interact securely with our API from a client-side web application (though you should never expose your secret API key in any public website's client-side code). <a href=\"http://www.json.org/\">JSON</a> is returned by all API responses, including errors.

- API version: v1
- Build date: 2018-12-03T15:15:47.060+05:30

## Requirements

PHP 5.4.0 and later, Curl

## Installation & Usage
Download the files and include `autoload.php`:

```php
    require_once('/path/to/website_toolbox_php_sdk/autoload.php');
```

## Getting Started

**Sign up for WebsiteToolbox** – Before you begin, you need to sign up for a WebsiteToolbox account and retrieve your [API KEY] from Settings > Security section.

**Minimum requirements** – To run the SDK, your system will need to meet the
   [requirements], including having **PHP >= 5.4.0** and later.
Please follow the [installation procedure](#installation--usage) and then run the following:

Note: Replace [API_KEY] key with your Forum API key  which you can retrieve from Settings > Security section.

```php
<?php
require_once(__DIR__ . '/autoload.php');

$api_instance = new Websitetoolbox\Api\CategoriesApi();
$xApiKey = "API_KEY"; // string | 
$addCategory = new \Websitetoolbox\Model\AddCategory(); // \Websitetoolbox\Model\AddCategory | 

try {
    $result = $api_instance->createCategory($xApiKey, $addCategory);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling CategoriesApi->createCategory: ', $e->getMessage(), PHP_EOL;
}

?>
```

## Documentation for API Endpoints

All URIs are relative to *https://api.websitetoolbox.com/v1*

Class | Method | HTTP request | Description
------------ | ------------- | ------------- | -------------
*CategoriesApi* | [**createCategory**](docs/Api/CategoriesApi.md#createcategory) | **POST** /api/categories | Create a category
*CategoriesApi* | [**deleteCategory**](docs/Api/CategoriesApi.md#deletecategory) | **DELETE** /api/categories/{categoryId} | Delete a category
*CategoriesApi* | [**getCategories**](docs/Api/CategoriesApi.md#getcategories) | **GET** /api/categories | List categories
*CategoriesApi* | [**getCategory**](docs/Api/CategoriesApi.md#getcategory) | **GET** /api/categories/{categoryId} | Retrieve a category
*CategoriesApi* | [**updateCategory**](docs/Api/CategoriesApi.md#updatecategory) | **POST** /api/categories/{categoryId} | Update a category
*ConversationsApi* | [**createConversation**](docs/Api/ConversationsApi.md#createconversation) | **POST** /api/conversations | Create a conversation
*ConversationsApi* | [**createMessage**](docs/Api/ConversationsApi.md#createmessage) | **POST** /api/conversations/{conversationId}/messages | Create a new message for a conversation
*ConversationsApi* | [**deleteConversation**](docs/Api/ConversationsApi.md#deleteconversation) | **DELETE** /api/conversations/{conversationId} | Delete a conversation
*ConversationsApi* | [**getConversation**](docs/Api/ConversationsApi.md#getconversation) | **GET** /api/conversations/{conversationId} | Retrieve a conversation
*ConversationsApi* | [**getConversations**](docs/Api/ConversationsApi.md#getconversations) | **GET** /api/conversations | List conversations
*ConversationsApi* | [**getMessage**](docs/Api/ConversationsApi.md#getmessage) | **GET** /api/conversations/{conversationId}/messages/{messageId} | Retrieve a message
*ConversationsApi* | [**getMessages**](docs/Api/ConversationsApi.md#getmessages) | **GET** /api/conversations/{conversationId}/messages | List messages for a conversation
*PostsApi* | [**createPost**](docs/Api/PostsApi.md#createpost) | **POST** /api/posts | Create a post
*PostsApi* | [**deletePost**](docs/Api/PostsApi.md#deletepost) | **DELETE** /api/posts/{postId} | Delete a post
*PostsApi* | [**getPost**](docs/Api/PostsApi.md#getpost) | **GET** /api/posts/{postId} | Retrieve a post
*PostsApi* | [**getPosts**](docs/Api/PostsApi.md#getposts) | **GET** /api/posts | List posts
*PostsApi* | [**updatePost**](docs/Api/PostsApi.md#updatepost) | **POST** /api/posts/{postId} | Update a post
*TopicsApi* | [**createTopic**](docs/Api/TopicsApi.md#createtopic) | **POST** /api/topics | Create a topic
*TopicsApi* | [**deleteTopic**](docs/Api/TopicsApi.md#deletetopic) | **DELETE** /api/topics/{topicId} | Delete a topic
*TopicsApi* | [**getTopic**](docs/Api/TopicsApi.md#gettopic) | **GET** /api/topics/{topicId} | Retrieve a topic
*TopicsApi* | [**getTopics**](docs/Api/TopicsApi.md#gettopics) | **GET** /api/topics | List topics
*TopicsApi* | [**updateTopic**](docs/Api/TopicsApi.md#updatetopic) | **POST** /api/topics/{topicId} | Update a topic
*UserGroupsApi* | [**createUserGroup**](docs/Api/UserGroupsApi.md#createusergroup) | **POST** /api/usergroups | Create a user group
*UserGroupsApi* | [**deleteUserGroup**](docs/Api/UserGroupsApi.md#deleteusergroup) | **DELETE** /api/usergroups/{userGroupId} | Delete a custom user group
*UserGroupsApi* | [**getUserGroup**](docs/Api/UserGroupsApi.md#getusergroup) | **GET** /api/usergroups/{userGroupId} | Retrieve a user group
*UserGroupsApi* | [**getUserGroups**](docs/Api/UserGroupsApi.md#getusergroups) | **GET** /api/usergroups | List user groups
*UserGroupsApi* | [**updateUserGroup**](docs/Api/UserGroupsApi.md#updateusergroup) | **POST** /api/usergroups/{userGroupId} | Update a user group
*UsersApi* | [**createUser**](docs/Api/UsersApi.md#createuser) | **POST** /api/users | Add a new user to the forum
*UsersApi* | [**deleteUser**](docs/Api/UsersApi.md#deleteuser) | **DELETE** /api/users/{userId} | Delete a user
*UsersApi* | [**getUser**](docs/Api/UsersApi.md#getuser) | **GET** /api/users/{userId} | Retrieve a user
*UsersApi* | [**getUsers**](docs/Api/UsersApi.md#getusers) | **GET** /api/users | List users
*UsersApi* | [**updateUser**](docs/Api/UsersApi.md#updateuser) | **POST** /api/users/{userId} | Update a user


## Documentation For Models

 - [AddCategory](docs/Model/AddCategory.md)
 - [AddConversation](docs/Model/AddConversation.md)
 - [AddMessage](docs/Model/AddMessage.md)
 - [AddPost](docs/Model/AddPost.md)
 - [AddTopic](docs/Model/AddTopic.md)
 - [AddUser](docs/Model/AddUser.md)
 - [AddUserCustomFields](docs/Model/AddUserCustomFields.md)
 - [AddUserGroup](docs/Model/AddUserGroup.md)
 - [Category](docs/Model/Category.md)
 - [Conversation](docs/Model/Conversation.md)
 - [ConversationParticipants](docs/Model/ConversationParticipants.md)
 - [DeleteResponse](docs/Model/DeleteResponse.md)
 - [Error](docs/Model/Error.md)
 - [ErrorError](docs/Model/ErrorError.md)
 - [ListCategories](docs/Model/ListCategories.md)
 - [ListCategoriesData](docs/Model/ListCategoriesData.md)
 - [ListConversations](docs/Model/ListConversations.md)
 - [ListConversationsData](docs/Model/ListConversationsData.md)
 - [ListMessages](docs/Model/ListMessages.md)
 - [ListMessagesData](docs/Model/ListMessagesData.md)
 - [ListMessagesSender](docs/Model/ListMessagesSender.md)
 - [ListPosts](docs/Model/ListPosts.md)
 - [ListPostsData](docs/Model/ListPostsData.md)
 - [ListTopics](docs/Model/ListTopics.md)
 - [ListTopicsAuthor](docs/Model/ListTopicsAuthor.md)
 - [ListTopicsData](docs/Model/ListTopicsData.md)
 - [ListTopicsLastPost](docs/Model/ListTopicsLastPost.md)
 - [ListTopicsLastPostAuthor](docs/Model/ListTopicsLastPostAuthor.md)
 - [ListUserGroups](docs/Model/ListUserGroups.md)
 - [ListUserGroupsData](docs/Model/ListUserGroupsData.md)
 - [ListUsers](docs/Model/ListUsers.md)
 - [ListUsersData](docs/Model/ListUsersData.md)
 - [Message](docs/Model/Message.md)
 - [MessageAttachments](docs/Model/MessageAttachments.md)
 - [MessageSender](docs/Model/MessageSender.md)
 - [Post](docs/Model/Post.md)
 - [PostAttachments](docs/Model/PostAttachments.md)
 - [PostAuthor](docs/Model/PostAuthor.md)
 - [Topic](docs/Model/Topic.md)
 - [TopicAuthor](docs/Model/TopicAuthor.md)
 - [TopicLastPost](docs/Model/TopicLastPost.md)
 - [UpdateUser](docs/Model/UpdateUser.md)
 - [User](docs/Model/User.md)
 - [UserCustomFields](docs/Model/UserCustomFields.md)
 - [Usergroup](docs/Model/Usergroup.md)


## Documentation For Authorization


## api_key

- **Type**: API key
- **API key parameter name**: x-api-key
- **Location**: HTTP header


## Author




