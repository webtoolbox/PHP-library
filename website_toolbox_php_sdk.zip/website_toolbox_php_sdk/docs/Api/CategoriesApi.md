# Websitetoolbox\CategoriesApi

All URIs are relative to *https://api.websitetoolbox.com/v1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**createCategory**](CategoriesApi.md#createCategory) | **POST** /api/categories | Create a category
[**deleteCategory**](CategoriesApi.md#deleteCategory) | **DELETE** /api/categories/{categoryId} | Delete a category
[**getCategories**](CategoriesApi.md#getCategories) | **GET** /api/categories | List categories
[**getCategory**](CategoriesApi.md#getCategory) | **GET** /api/categories/{categoryId} | Retrieve a category
[**updateCategory**](CategoriesApi.md#updateCategory) | **POST** /api/categories/{categoryId} | Update a category


# **createCategory**
> \Websitetoolbox\Model\Category createCategory($xApiKey, $addCategory)

Create a category

Creates a new category object.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure API key authorization: api_key
Websitetoolbox\Configuration::getDefaultConfiguration()->setApiKey('x-api-key', 'YOUR_API_KEY');
// Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
// Websitetoolbox\Configuration::getDefaultConfiguration()->setApiKeyPrefix('x-api-key', 'Bearer');

$api_instance = new Websitetoolbox\Api\CategoriesApi();
$xApiKey = "xApiKey_example"; // string | 
$addCategory = new \Websitetoolbox\Model\AddCategory(); // \Websitetoolbox\Model\AddCategory | 

try {
    $result = $api_instance->createCategory($xApiKey, $addCategory);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling CategoriesApi->createCategory: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **xApiKey** | **string**|  |
 **addCategory** | [**\Websitetoolbox\Model\AddCategory**](../Model/\Websitetoolbox\Model\AddCategory.md)|  |

### Return type

[**\Websitetoolbox\Model\Category**](../Model/Category.md)

### Authorization

[api_key](../../README.md#api_key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **deleteCategory**
> \Websitetoolbox\Model\DeleteResponse deleteCategory($categoryId, $xApiKey)

Delete a category

Permanently deletes a category. It cannot be undone. Also immediately deletes any topics and posts on the category.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure API key authorization: api_key
Websitetoolbox\Configuration::getDefaultConfiguration()->setApiKey('x-api-key', 'YOUR_API_KEY');
// Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
// Websitetoolbox\Configuration::getDefaultConfiguration()->setApiKeyPrefix('x-api-key', 'Bearer');

$api_instance = new Websitetoolbox\Api\CategoriesApi();
$categoryId = "categoryId_example"; // string | 
$xApiKey = "xApiKey_example"; // string | 

try {
    $result = $api_instance->deleteCategory($categoryId, $xApiKey);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling CategoriesApi->deleteCategory: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **categoryId** | **string**|  |
 **xApiKey** | **string**|  |

### Return type

[**\Websitetoolbox\Model\DeleteResponse**](../Model/DeleteResponse.md)

### Authorization

[api_key](../../README.md#api_key)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **getCategories**
> \Websitetoolbox\Model\ListCategories getCategories($xApiKey, $limit, $page)

List categories

Returns a list of categories. The categories are returned sorted by displayorder, minimum displayorder category appearing first.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure API key authorization: api_key
Websitetoolbox\Configuration::getDefaultConfiguration()->setApiKey('x-api-key', 'YOUR_API_KEY');
// Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
// Websitetoolbox\Configuration::getDefaultConfiguration()->setApiKeyPrefix('x-api-key', 'Bearer');

$api_instance = new Websitetoolbox\Api\CategoriesApi();
$xApiKey = "xApiKey_example"; // string | 
$limit = "limit_example"; // string | 
$page = "page_example"; // string | 

try {
    $result = $api_instance->getCategories($xApiKey, $limit, $page);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling CategoriesApi->getCategories: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **xApiKey** | **string**|  |
 **limit** | **string**|  | [optional]
 **page** | **string**|  | [optional]

### Return type

[**\Websitetoolbox\Model\ListCategories**](../Model/ListCategories.md)

### Authorization

[api_key](../../README.md#api_key)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **getCategory**
> \Websitetoolbox\Model\Category getCategory($categoryId, $xApiKey)

Retrieve a category

Retrieves the details of an existing category. You need only supply the unique category identifier that was returned upon customer creation.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure API key authorization: api_key
Websitetoolbox\Configuration::getDefaultConfiguration()->setApiKey('x-api-key', 'YOUR_API_KEY');
// Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
// Websitetoolbox\Configuration::getDefaultConfiguration()->setApiKeyPrefix('x-api-key', 'Bearer');

$api_instance = new Websitetoolbox\Api\CategoriesApi();
$categoryId = "categoryId_example"; // string | 
$xApiKey = "xApiKey_example"; // string | 

try {
    $result = $api_instance->getCategory($categoryId, $xApiKey);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling CategoriesApi->getCategory: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **categoryId** | **string**|  |
 **xApiKey** | **string**|  |

### Return type

[**\Websitetoolbox\Model\Category**](../Model/Category.md)

### Authorization

[api_key](../../README.md#api_key)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **updateCategory**
> \Websitetoolbox\Model\Category updateCategory($categoryId, $xApiKey, $category)

Update a category

Updates the specified category by setting the values of the parameters passed. Any parameters not provided will be left unchanged. This request accepts mostly the same arguments as the category creation call.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure API key authorization: api_key
Websitetoolbox\Configuration::getDefaultConfiguration()->setApiKey('x-api-key', 'YOUR_API_KEY');
// Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
// Websitetoolbox\Configuration::getDefaultConfiguration()->setApiKeyPrefix('x-api-key', 'Bearer');

$api_instance = new Websitetoolbox\Api\CategoriesApi();
$categoryId = "categoryId_example"; // string | 
$xApiKey = "xApiKey_example"; // string | 
$category = new \Websitetoolbox\Model\Category(); // \Websitetoolbox\Model\Category | 

try {
    $result = $api_instance->updateCategory($categoryId, $xApiKey, $category);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling CategoriesApi->updateCategory: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **categoryId** | **string**|  |
 **xApiKey** | **string**|  |
 **category** | [**\Websitetoolbox\Model\Category**](../Model/\Websitetoolbox\Model\Category.md)|  |

### Return type

[**\Websitetoolbox\Model\Category**](../Model/Category.md)

### Authorization

[api_key](../../README.md#api_key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

