# Websitetoolbox\ConversationsApi

All URIs are relative to *https://api.websitetoolbox.com/v1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**createConversation**](ConversationsApi.md#createConversation) | **POST** /api/conversations | Create a conversation
[**createMessage**](ConversationsApi.md#createMessage) | **POST** /api/conversations/{conversationId}/messages | Create a new message for a conversation
[**deleteConversation**](ConversationsApi.md#deleteConversation) | **DELETE** /api/conversations/{conversationId} | Delete a conversation
[**getConversation**](ConversationsApi.md#getConversation) | **GET** /api/conversations/{conversationId} | Retrieve a conversation
[**getConversations**](ConversationsApi.md#getConversations) | **GET** /api/conversations | List conversations
[**getMessage**](ConversationsApi.md#getMessage) | **GET** /api/conversations/{conversationId}/messages/{messageId} | Retrieve a message
[**getMessages**](ConversationsApi.md#getMessages) | **GET** /api/conversations/{conversationId}/messages | List messages for a conversation


# **createConversation**
> \Websitetoolbox\Model\Conversation createConversation($xApiKey, $addConversation)

Create a conversation

Creates a new conversation  to the forum.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure API key authorization: api_key
Websitetoolbox\Configuration::getDefaultConfiguration()->setApiKey('x-api-key', 'YOUR_API_KEY');
// Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
// Websitetoolbox\Configuration::getDefaultConfiguration()->setApiKeyPrefix('x-api-key', 'Bearer');

$api_instance = new Websitetoolbox\Api\ConversationsApi();
$xApiKey = "xApiKey_example"; // string | 
$addConversation = new \Websitetoolbox\Model\AddConversation(); // \Websitetoolbox\Model\AddConversation | 

try {
    $result = $api_instance->createConversation($xApiKey, $addConversation);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ConversationsApi->createConversation: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **xApiKey** | **string**|  |
 **addConversation** | [**\Websitetoolbox\Model\AddConversation**](../Model/\Websitetoolbox\Model\AddConversation.md)|  |

### Return type

[**\Websitetoolbox\Model\Conversation**](../Model/Conversation.md)

### Authorization

[api_key](../../README.md#api_key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **createMessage**
> \Websitetoolbox\Model\Message createMessage($xApiKey, $conversationId, $addMessage)

Create a new message for a conversation

Creates a new message

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure API key authorization: api_key
Websitetoolbox\Configuration::getDefaultConfiguration()->setApiKey('x-api-key', 'YOUR_API_KEY');
// Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
// Websitetoolbox\Configuration::getDefaultConfiguration()->setApiKeyPrefix('x-api-key', 'Bearer');

$api_instance = new Websitetoolbox\Api\ConversationsApi();
$xApiKey = "xApiKey_example"; // string | 
$conversationId = "conversationId_example"; // string | 
$addMessage = new \Websitetoolbox\Model\AddMessage(); // \Websitetoolbox\Model\AddMessage | 

try {
    $result = $api_instance->createMessage($xApiKey, $conversationId, $addMessage);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ConversationsApi->createMessage: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **xApiKey** | **string**|  |
 **conversationId** | **string**|  |
 **addMessage** | [**\Websitetoolbox\Model\AddMessage**](../Model/\Websitetoolbox\Model\AddMessage.md)|  |

### Return type

[**\Websitetoolbox\Model\Message**](../Model/Message.md)

### Authorization

[api_key](../../README.md#api_key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **deleteConversation**
> \Websitetoolbox\Model\DeleteResponse deleteConversation($xApiKey, $conversationId)

Delete a conversation

Permanently deletes a customer. It cannot be undone.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure API key authorization: api_key
Websitetoolbox\Configuration::getDefaultConfiguration()->setApiKey('x-api-key', 'YOUR_API_KEY');
// Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
// Websitetoolbox\Configuration::getDefaultConfiguration()->setApiKeyPrefix('x-api-key', 'Bearer');

$api_instance = new Websitetoolbox\Api\ConversationsApi();
$xApiKey = "xApiKey_example"; // string | 
$conversationId = "conversationId_example"; // string | 

try {
    $result = $api_instance->deleteConversation($xApiKey, $conversationId);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ConversationsApi->deleteConversation: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **xApiKey** | **string**|  |
 **conversationId** | **string**|  |

### Return type

[**\Websitetoolbox\Model\DeleteResponse**](../Model/DeleteResponse.md)

### Authorization

[api_key](../../README.md#api_key)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **getConversation**
> \Websitetoolbox\Model\Conversation getConversation($xApiKey, $conversationId)

Retrieve a conversation

Retrieves the details of an existing conversation. You need only supply the unique conversation identifier that was returned upon conversation creation.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure API key authorization: api_key
Websitetoolbox\Configuration::getDefaultConfiguration()->setApiKey('x-api-key', 'YOUR_API_KEY');
// Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
// Websitetoolbox\Configuration::getDefaultConfiguration()->setApiKeyPrefix('x-api-key', 'Bearer');

$api_instance = new Websitetoolbox\Api\ConversationsApi();
$xApiKey = "xApiKey_example"; // string | 
$conversationId = "conversationId_example"; // string | 

try {
    $result = $api_instance->getConversation($xApiKey, $conversationId);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ConversationsApi->getConversation: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **xApiKey** | **string**|  |
 **conversationId** | **string**|  |

### Return type

[**\Websitetoolbox\Model\Conversation**](../Model/Conversation.md)

### Authorization

[api_key](../../README.md#api_key)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **getConversations**
> \Websitetoolbox\Model\ListConversations getConversations($xApiKey, $userId, $limit, $page)

List conversations

Returns a list of conversations. The conversations are returned sorted by creation date, with the most recent conversations appearing first.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure API key authorization: api_key
Websitetoolbox\Configuration::getDefaultConfiguration()->setApiKey('x-api-key', 'YOUR_API_KEY');
// Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
// Websitetoolbox\Configuration::getDefaultConfiguration()->setApiKeyPrefix('x-api-key', 'Bearer');

$api_instance = new Websitetoolbox\Api\ConversationsApi();
$xApiKey = "xApiKey_example"; // string | 
$userId = "userId_example"; // string | 
$limit = "limit_example"; // string | 
$page = "page_example"; // string | 

try {
    $result = $api_instance->getConversations($xApiKey, $userId, $limit, $page);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ConversationsApi->getConversations: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **xApiKey** | **string**|  |
 **userId** | **string**|  | [optional]
 **limit** | **string**|  | [optional]
 **page** | **string**|  | [optional]

### Return type

[**\Websitetoolbox\Model\ListConversations**](../Model/ListConversations.md)

### Authorization

[api_key](../../README.md#api_key)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **getMessage**
> \Websitetoolbox\Model\Message getMessage($messageId, $xApiKey, $conversationId, $userId, $limit, $page)

Retrieve a message

Retrieves the details of an existing message. You need only supply the unique message identifier that was returned upon message creation.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure API key authorization: api_key
Websitetoolbox\Configuration::getDefaultConfiguration()->setApiKey('x-api-key', 'YOUR_API_KEY');
// Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
// Websitetoolbox\Configuration::getDefaultConfiguration()->setApiKeyPrefix('x-api-key', 'Bearer');

$api_instance = new Websitetoolbox\Api\ConversationsApi();
$messageId = "messageId_example"; // string | 
$xApiKey = "xApiKey_example"; // string | 
$conversationId = "conversationId_example"; // string | 
$userId = "userId_example"; // string | 
$limit = "limit_example"; // string | 
$page = "page_example"; // string | 

try {
    $result = $api_instance->getMessage($messageId, $xApiKey, $conversationId, $userId, $limit, $page);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ConversationsApi->getMessage: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **messageId** | **string**|  |
 **xApiKey** | **string**|  |
 **conversationId** | **string**|  |
 **userId** | **string**|  | [optional]
 **limit** | **string**|  | [optional]
 **page** | **string**|  | [optional]

### Return type

[**\Websitetoolbox\Model\Message**](../Model/Message.md)

### Authorization

[api_key](../../README.md#api_key)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **getMessages**
> \Websitetoolbox\Model\ListMessages getMessages($xApiKey, $conversationId, $userId, $limit, $page)

List messages for a conversation

Returns a list of your messages for a conversation. The messages are returned sorted by creation date, with the most recent messages appearing first.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure API key authorization: api_key
Websitetoolbox\Configuration::getDefaultConfiguration()->setApiKey('x-api-key', 'YOUR_API_KEY');
// Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
// Websitetoolbox\Configuration::getDefaultConfiguration()->setApiKeyPrefix('x-api-key', 'Bearer');

$api_instance = new Websitetoolbox\Api\ConversationsApi();
$xApiKey = "xApiKey_example"; // string | 
$conversationId = "conversationId_example"; // string | 
$userId = "userId_example"; // string | 
$limit = "limit_example"; // string | 
$page = "page_example"; // string | 

try {
    $result = $api_instance->getMessages($xApiKey, $conversationId, $userId, $limit, $page);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling ConversationsApi->getMessages: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **xApiKey** | **string**|  |
 **conversationId** | **string**|  |
 **userId** | **string**|  | [optional]
 **limit** | **string**|  | [optional]
 **page** | **string**|  | [optional]

### Return type

[**\Websitetoolbox\Model\ListMessages**](../Model/ListMessages.md)

### Authorization

[api_key](../../README.md#api_key)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

