# Websitetoolbox\PostsApi

All URIs are relative to *https://api.websitetoolbox.com/v1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**createPost**](PostsApi.md#createPost) | **POST** /api/posts | Create a post
[**deletePost**](PostsApi.md#deletePost) | **DELETE** /api/posts/{postId} | Delete a post
[**getPost**](PostsApi.md#getPost) | **GET** /api/posts/{postId} | Retrieve a post
[**getPosts**](PostsApi.md#getPosts) | **GET** /api/posts | List posts
[**updatePost**](PostsApi.md#updatePost) | **POST** /api/posts/{postId} | Update a post


# **createPost**
> \Websitetoolbox\Model\Post createPost($xApiKey, $addPost)

Create a post

Creates a new post

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure API key authorization: api_key
Websitetoolbox\Configuration::getDefaultConfiguration()->setApiKey('x-api-key', 'YOUR_API_KEY');
// Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
// Websitetoolbox\Configuration::getDefaultConfiguration()->setApiKeyPrefix('x-api-key', 'Bearer');

$api_instance = new Websitetoolbox\Api\PostsApi();
$xApiKey = "xApiKey_example"; // string | 
$addPost = new \Websitetoolbox\Model\AddPost(); // \Websitetoolbox\Model\AddPost | 

try {
    $result = $api_instance->createPost($xApiKey, $addPost);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling PostsApi->createPost: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **xApiKey** | **string**|  |
 **addPost** | [**\Websitetoolbox\Model\AddPost**](../Model/\Websitetoolbox\Model\AddPost.md)|  |

### Return type

[**\Websitetoolbox\Model\Post**](../Model/Post.md)

### Authorization

[api_key](../../README.md#api_key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **deletePost**
> \Websitetoolbox\Model\DeleteResponse deletePost($postId, $xApiKey)

Delete a post

Permanently deletes a post. It cannot be undone. Also immediately deletes any attachments on the post.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure API key authorization: api_key
Websitetoolbox\Configuration::getDefaultConfiguration()->setApiKey('x-api-key', 'YOUR_API_KEY');
// Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
// Websitetoolbox\Configuration::getDefaultConfiguration()->setApiKeyPrefix('x-api-key', 'Bearer');

$api_instance = new Websitetoolbox\Api\PostsApi();
$postId = "postId_example"; // string | 
$xApiKey = "xApiKey_example"; // string | 

try {
    $result = $api_instance->deletePost($postId, $xApiKey);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling PostsApi->deletePost: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **postId** | **string**|  |
 **xApiKey** | **string**|  |

### Return type

[**\Websitetoolbox\Model\DeleteResponse**](../Model/DeleteResponse.md)

### Authorization

[api_key](../../README.md#api_key)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **getPost**
> \Websitetoolbox\Model\Post getPost($postId, $xApiKey)

Retrieve a post

Retrieves the details of an existing post. You need only supply the unique post identifier that was returned upon post creation.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure API key authorization: api_key
Websitetoolbox\Configuration::getDefaultConfiguration()->setApiKey('x-api-key', 'YOUR_API_KEY');
// Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
// Websitetoolbox\Configuration::getDefaultConfiguration()->setApiKeyPrefix('x-api-key', 'Bearer');

$api_instance = new Websitetoolbox\Api\PostsApi();
$postId = "postId_example"; // string | 
$xApiKey = "xApiKey_example"; // string | 

try {
    $result = $api_instance->getPost($postId, $xApiKey);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling PostsApi->getPost: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **postId** | **string**|  |
 **xApiKey** | **string**|  |

### Return type

[**\Websitetoolbox\Model\Post**](../Model/Post.md)

### Authorization

[api_key](../../README.md#api_key)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **getPosts**
> \Websitetoolbox\Model\ListPosts getPosts($xApiKey, $userId, $topicId, $limit, $page, $categoryId)

List posts

Returns a list of posts. The posts are returned sorted by creation date, with the most recent posts appearing first.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure API key authorization: api_key
Websitetoolbox\Configuration::getDefaultConfiguration()->setApiKey('x-api-key', 'YOUR_API_KEY');
// Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
// Websitetoolbox\Configuration::getDefaultConfiguration()->setApiKeyPrefix('x-api-key', 'Bearer');

$api_instance = new Websitetoolbox\Api\PostsApi();
$xApiKey = "xApiKey_example"; // string | 
$userId = "userId_example"; // string | 
$topicId = "topicId_example"; // string | 
$limit = "limit_example"; // string | 
$page = "page_example"; // string | 
$categoryId = "categoryId_example"; // string | 

try {
    $result = $api_instance->getPosts($xApiKey, $userId, $topicId, $limit, $page, $categoryId);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling PostsApi->getPosts: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **xApiKey** | **string**|  |
 **userId** | **string**|  | [optional]
 **topicId** | **string**|  | [optional]
 **limit** | **string**|  | [optional]
 **page** | **string**|  | [optional]
 **categoryId** | **string**|  | [optional]

### Return type

[**\Websitetoolbox\Model\ListPosts**](../Model/ListPosts.md)

### Authorization

[api_key](../../README.md#api_key)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **updatePost**
> \Websitetoolbox\Model\Post updatePost($postId, $xApiKey)

Update a post

Updates the specified post by setting the values of the parameters passed. Any parameters not provided will be left unchanged.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure API key authorization: api_key
Websitetoolbox\Configuration::getDefaultConfiguration()->setApiKey('x-api-key', 'YOUR_API_KEY');
// Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
// Websitetoolbox\Configuration::getDefaultConfiguration()->setApiKeyPrefix('x-api-key', 'Bearer');

$api_instance = new Websitetoolbox\Api\PostsApi();
$postId = "postId_example"; // string | 
$xApiKey = "xApiKey_example"; // string | 

try {
    $result = $api_instance->updatePost($postId, $xApiKey);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling PostsApi->updatePost: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **postId** | **string**|  |
 **xApiKey** | **string**|  |

### Return type

[**\Websitetoolbox\Model\Post**](../Model/Post.md)

### Authorization

[api_key](../../README.md#api_key)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

