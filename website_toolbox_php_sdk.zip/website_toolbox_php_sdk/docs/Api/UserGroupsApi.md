# Websitetoolbox\UserGroupsApi

All URIs are relative to *https://api.websitetoolbox.com/v1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**createUserGroup**](UserGroupsApi.md#createUserGroup) | **POST** /api/usergroups | Create a user group
[**deleteUserGroup**](UserGroupsApi.md#deleteUserGroup) | **DELETE** /api/usergroups/{userGroupId} | Delete a custom user group
[**getUserGroup**](UserGroupsApi.md#getUserGroup) | **GET** /api/usergroups/{userGroupId} | Retrieve a user group
[**getUserGroups**](UserGroupsApi.md#getUserGroups) | **GET** /api/usergroups | List user groups
[**updateUserGroup**](UserGroupsApi.md#updateUserGroup) | **POST** /api/usergroups/{userGroupId} | Update a user group


# **createUserGroup**
> \Websitetoolbox\Model\UserGroup createUserGroup($xApiKey, $addUserGroup)

Create a user group

Creates a custom user group

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure API key authorization: api_key
Websitetoolbox\Configuration::getDefaultConfiguration()->setApiKey('x-api-key', 'YOUR_API_KEY');
// Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
// Websitetoolbox\Configuration::getDefaultConfiguration()->setApiKeyPrefix('x-api-key', 'Bearer');

$api_instance = new Websitetoolbox\Api\UserGroupsApi();
$xApiKey = "xApiKey_example"; // string | 
$addUserGroup = new \Websitetoolbox\Model\AddUserGroup(); // \Websitetoolbox\Model\AddUserGroup | 

try {
    $result = $api_instance->createUserGroup($xApiKey, $addUserGroup);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling UserGroupsApi->createUserGroup: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **xApiKey** | **string**|  |
 **addUserGroup** | [**\Websitetoolbox\Model\AddUserGroup**](../Model/\Websitetoolbox\Model\AddUserGroup.md)|  |

### Return type

[**\Websitetoolbox\Model\UserGroup**](../Model/UserGroup.md)

### Authorization

[api_key](../../README.md#api_key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **deleteUserGroup**
> \Websitetoolbox\Model\DeleteResponse deleteUserGroup($xApiKey, $userGroupId)

Delete a custom user group

Permanently deletes a custom user group. It cannot be undone.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure API key authorization: api_key
Websitetoolbox\Configuration::getDefaultConfiguration()->setApiKey('x-api-key', 'YOUR_API_KEY');
// Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
// Websitetoolbox\Configuration::getDefaultConfiguration()->setApiKeyPrefix('x-api-key', 'Bearer');

$api_instance = new Websitetoolbox\Api\UserGroupsApi();
$xApiKey = "xApiKey_example"; // string | 
$userGroupId = "userGroupId_example"; // string | 

try {
    $result = $api_instance->deleteUserGroup($xApiKey, $userGroupId);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling UserGroupsApi->deleteUserGroup: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **xApiKey** | **string**|  |
 **userGroupId** | **string**|  |

### Return type

[**\Websitetoolbox\Model\DeleteResponse**](../Model/DeleteResponse.md)

### Authorization

[api_key](../../README.md#api_key)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **getUserGroup**
> \Websitetoolbox\Model\UserGroup getUserGroup($xApiKey, $userGroupId)

Retrieve a user group

Retrieves the details of an existing user group. You need only supply the unique user group identifier.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure API key authorization: api_key
Websitetoolbox\Configuration::getDefaultConfiguration()->setApiKey('x-api-key', 'YOUR_API_KEY');
// Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
// Websitetoolbox\Configuration::getDefaultConfiguration()->setApiKeyPrefix('x-api-key', 'Bearer');

$api_instance = new Websitetoolbox\Api\UserGroupsApi();
$xApiKey = "xApiKey_example"; // string | 
$userGroupId = "userGroupId_example"; // string | 

try {
    $result = $api_instance->getUserGroup($xApiKey, $userGroupId);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling UserGroupsApi->getUserGroup: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **xApiKey** | **string**|  |
 **userGroupId** | **string**|  |

### Return type

[**\Websitetoolbox\Model\UserGroup**](../Model/UserGroup.md)

### Authorization

[api_key](../../README.md#api_key)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **getUserGroups**
> \Websitetoolbox\Model\ListUserGroups getUserGroups($xApiKey, $limit, $page)

List user groups

Returns a list of all user groups.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure API key authorization: api_key
Websitetoolbox\Configuration::getDefaultConfiguration()->setApiKey('x-api-key', 'YOUR_API_KEY');
// Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
// Websitetoolbox\Configuration::getDefaultConfiguration()->setApiKeyPrefix('x-api-key', 'Bearer');

$api_instance = new Websitetoolbox\Api\UserGroupsApi();
$xApiKey = "xApiKey_example"; // string | 
$limit = "limit_example"; // string | 
$page = "page_example"; // string | 

try {
    $result = $api_instance->getUserGroups($xApiKey, $limit, $page);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling UserGroupsApi->getUserGroups: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **xApiKey** | **string**|  |
 **limit** | **string**|  | [optional]
 **page** | **string**|  | [optional]

### Return type

[**\Websitetoolbox\Model\ListUserGroups**](../Model/ListUserGroups.md)

### Authorization

[api_key](../../README.md#api_key)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **updateUserGroup**
> \Websitetoolbox\Model\UserGroup updateUserGroup($xApiKey, $userGroupId, $userGroup)

Update a user group

Update the user group

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure API key authorization: api_key
Websitetoolbox\Configuration::getDefaultConfiguration()->setApiKey('x-api-key', 'YOUR_API_KEY');
// Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
// Websitetoolbox\Configuration::getDefaultConfiguration()->setApiKeyPrefix('x-api-key', 'Bearer');

$api_instance = new Websitetoolbox\Api\UserGroupsApi();
$xApiKey = "xApiKey_example"; // string | 
$userGroupId = "userGroupId_example"; // string | 
$userGroup = new \Websitetoolbox\Model\UserGroup(); // \Websitetoolbox\Model\UserGroup | 

try {
    $result = $api_instance->updateUserGroup($xApiKey, $userGroupId, $userGroup);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling UserGroupsApi->updateUserGroup: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **xApiKey** | **string**|  |
 **userGroupId** | **string**|  |
 **userGroup** | [**\Websitetoolbox\Model\UserGroup**](../Model/\Websitetoolbox\Model\UserGroup.md)|  |

### Return type

[**\Websitetoolbox\Model\UserGroup**](../Model/UserGroup.md)

### Authorization

[api_key](../../README.md#api_key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

