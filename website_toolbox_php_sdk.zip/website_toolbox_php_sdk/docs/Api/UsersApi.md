# Websitetoolbox\UsersApi

All URIs are relative to *https://api.websitetoolbox.com/v1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**createUser**](UsersApi.md#createUser) | **POST** /api/users | Add a new user to the forum
[**deleteUser**](UsersApi.md#deleteUser) | **DELETE** /api/users/{userId} | Delete a user
[**getUser**](UsersApi.md#getUser) | **GET** /api/users/{userId} | Retrieve a user
[**getUsers**](UsersApi.md#getUsers) | **GET** /api/users | List users
[**updateUser**](UsersApi.md#updateUser) | **POST** /api/users/{userId} | Update a user


# **createUser**
> \Websitetoolbox\Model\User createUser($xApiKey, $addUser)

Add a new user to the forum

Creates a new user  on forum

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure API key authorization: api_key
Websitetoolbox\Configuration::getDefaultConfiguration()->setApiKey('x-api-key', 'YOUR_API_KEY');
// Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
// Websitetoolbox\Configuration::getDefaultConfiguration()->setApiKeyPrefix('x-api-key', 'Bearer');

$api_instance = new Websitetoolbox\Api\UsersApi();
$xApiKey = "xApiKey_example"; // string | 
$addUser = new \Websitetoolbox\Model\AddUser(); // \Websitetoolbox\Model\AddUser | 

try {
    $result = $api_instance->createUser($xApiKey, $addUser);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling UsersApi->createUser: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **xApiKey** | **string**|  |
 **addUser** | [**\Websitetoolbox\Model\AddUser**](../Model/\Websitetoolbox\Model\AddUser.md)|  |

### Return type

[**\Websitetoolbox\Model\User**](../Model/User.md)

### Authorization

[api_key](../../README.md#api_key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **deleteUser**
> \Websitetoolbox\Model\DeleteResponse deleteUser($xApiKey, $userId)

Delete a user

Permanently deletes a user. It cannot be undone.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure API key authorization: api_key
Websitetoolbox\Configuration::getDefaultConfiguration()->setApiKey('x-api-key', 'YOUR_API_KEY');
// Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
// Websitetoolbox\Configuration::getDefaultConfiguration()->setApiKeyPrefix('x-api-key', 'Bearer');

$api_instance = new Websitetoolbox\Api\UsersApi();
$xApiKey = "xApiKey_example"; // string | 
$userId = "userId_example"; // string | 

try {
    $result = $api_instance->deleteUser($xApiKey, $userId);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling UsersApi->deleteUser: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **xApiKey** | **string**|  |
 **userId** | **string**|  |

### Return type

[**\Websitetoolbox\Model\DeleteResponse**](../Model/DeleteResponse.md)

### Authorization

[api_key](../../README.md#api_key)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **getUser**
> \Websitetoolbox\Model\User getUser($xApiKey, $userId)

Retrieve a user

Retrieves the details of an existing user. You need only supply the unique user identifier that was returned upon user creation.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure API key authorization: api_key
Websitetoolbox\Configuration::getDefaultConfiguration()->setApiKey('x-api-key', 'YOUR_API_KEY');
// Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
// Websitetoolbox\Configuration::getDefaultConfiguration()->setApiKeyPrefix('x-api-key', 'Bearer');

$api_instance = new Websitetoolbox\Api\UsersApi();
$xApiKey = "xApiKey_example"; // string | 
$userId = "userId_example"; // string | 

try {
    $result = $api_instance->getUser($xApiKey, $userId);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling UsersApi->getUser: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **xApiKey** | **string**|  |
 **userId** | **string**|  |

### Return type

[**\Websitetoolbox\Model\User**](../Model/User.md)

### Authorization

[api_key](../../README.md#api_key)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **getUsers**
> \Websitetoolbox\Model\ListUsers getUsers($xApiKey, $limit, $page, $userGroupId)

List users

Returns a list of users on forum. The users are returned sorted by creation date, with the most recent users appearing first.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure API key authorization: api_key
Websitetoolbox\Configuration::getDefaultConfiguration()->setApiKey('x-api-key', 'YOUR_API_KEY');
// Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
// Websitetoolbox\Configuration::getDefaultConfiguration()->setApiKeyPrefix('x-api-key', 'Bearer');

$api_instance = new Websitetoolbox\Api\UsersApi();
$xApiKey = "xApiKey_example"; // string | 
$limit = "limit_example"; // string | Limit the results for a particular request. Minimum is 1, maximum is 100 and default value is 10.
$page = "page_example"; // string | Page number of results to return.
$userGroupId = "userGroupId_example"; // string | The userGroupId of user to retrieve from results.

try {
    $result = $api_instance->getUsers($xApiKey, $limit, $page, $userGroupId);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling UsersApi->getUsers: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **xApiKey** | **string**|  |
 **limit** | **string**| Limit the results for a particular request. Minimum is 1, maximum is 100 and default value is 10. | [optional]
 **page** | **string**| Page number of results to return. | [optional]
 **userGroupId** | **string**| The userGroupId of user to retrieve from results. | [optional]

### Return type

[**\Websitetoolbox\Model\ListUsers**](../Model/ListUsers.md)

### Authorization

[api_key](../../README.md#api_key)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **updateUser**
> \Websitetoolbox\Model\User updateUser($xApiKey, $userId, $updateUser)

Update a user

Updates the specified user by setting the values of the parameters passed. Any parameters not provided will be left unchanged. <p>This request accepts mostly the same arguments as the user creation call.</p>

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure API key authorization: api_key
Websitetoolbox\Configuration::getDefaultConfiguration()->setApiKey('x-api-key', 'YOUR_API_KEY');
// Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
// Websitetoolbox\Configuration::getDefaultConfiguration()->setApiKeyPrefix('x-api-key', 'Bearer');

$api_instance = new Websitetoolbox\Api\UsersApi();
$xApiKey = "xApiKey_example"; // string | 
$userId = "userId_example"; // string | 
$updateUser = new \Websitetoolbox\Model\UpdateUser(); // \Websitetoolbox\Model\UpdateUser | 

try {
    $result = $api_instance->updateUser($xApiKey, $userId, $updateUser);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling UsersApi->updateUser: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **xApiKey** | **string**|  |
 **userId** | **string**|  |
 **updateUser** | [**\Websitetoolbox\Model\UpdateUser**](../Model/\Websitetoolbox\Model\UpdateUser.md)|  |

### Return type

[**\Websitetoolbox\Model\User**](../Model/User.md)

### Authorization

[api_key](../../README.md#api_key)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

