# AddConversation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**message** | **string** | Message is usually a content, and its purpose is either to ask a question, answer a question or to contributes towards the forum discussion by expressing an opinion or bringing forth information. | [optional] 
**recipientUsernames** | **string[]** | A list of usernames who will receive the messages. | [optional] 
**subject** | **string** | Thing that is being discussed, described for conversation. | [optional] 
**senderId** | **int** | Sender&#39;s userId who started the conversation. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


