# AddPost

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**content** | **string** | Content is usually a message, and its purpose is either to ask a question, answer a question or to contributes towards the forum discussion by expressing an opinion or bringing forth information. | 
**username** | **string** | The username of member to create this object. | 
**topicId** | **int** | The unique identifier of topic to create this object. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


