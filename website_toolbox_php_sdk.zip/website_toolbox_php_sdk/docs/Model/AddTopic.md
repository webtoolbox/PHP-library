# AddTopic

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**title** | **string** | Thing that is being discussed, described for topic. | 
**content** | **string** | Content is usually a message, and its purpose is either to ask a question, answer a question or to contributes towards the forum discussion by expressing an opinion or bringing forth information. | 
**username** | **string** | The username of member to create this object. | 
**categoryId** | **int** | The unique identifier of category to create this object. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


