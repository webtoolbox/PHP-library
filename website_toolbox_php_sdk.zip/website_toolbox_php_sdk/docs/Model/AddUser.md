# AddUser

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**username** | **string** | The username of the member. | 
**password** | **string** | The password of the member. | 
**email** | **string** | The email address of the member. | 
**userGroups** | **int[]** | A list of user groups that belongs to this member. | [optional] 
**signature** | **string** | Signature of member. | [optional] 
**name** | **string** | The name of the member. | [optional] 
**instantMessagingType** | **string** | Instant messaging type of the member. | [optional] 
**instantMessagingId** | **string** | Instant messaging id of the member. | [optional] 
**birthday** | **string** | Birthday of the member. | [optional] 
**customFields** | [**\Websitetoolbox\Model\AddUserCustomFields[]**](AddUserCustomFields.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


