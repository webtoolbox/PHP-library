# AddUserCustomFields

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**profileFieldId** | **int** | The unique identifier of custom field that belongs to this object. | [optional] 
**value** | **string** | The value of custom field. It can be string or array of strings depending on the type of custom field. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


