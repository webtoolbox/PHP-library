# AddUserGroup

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**title** | **string** | This is the name of user group. It is not shown to members but used to identify in User Group Manager. | 
**viewInvisibleMembers** | **bool** | The viewInvisibleMembers permission to create this object. | [optional] 
**viewOthersTopics** | **bool** | The viewOthersTopics permission to create this object. | [optional] 
**viewableOnMembersList** | **bool** | The viewableOnMembersList permission to create this object. | [optional] 
**uploadAttachments** | **bool** | The uploadAttachments permission to create this object. | [optional] 
**changeUsername** | **bool** | The changeUsername permission to create this object. | [optional] 
**viewForum** | **bool** | The viewForum permission to create this object. | [optional] 
**startTopics** | **bool** | The startTopics permission to create this object. | [optional] 
**deleteOwnTopics** | **bool** | The deleteOwnTopics permission to create this object. | [optional] 
**createAlbums** | **bool** | The createAlbums permission to create this object. | [optional] 
**moveOwnTopics** | **bool** | The moveOwnTopics permission to create this object. | [optional] 
**viewAttachments** | **bool** | The viewAttachments permission to create this object. | [optional] 
**editOwnProfile** | **bool** | The editOwnProfile permission to create this object. | [optional] 
**customTitle** | **bool** | The customTitle permission to create this object. | [optional] 
**viewAlbums** | **bool** | The viewAlbums permission to create this object. | [optional] 
**signature** | **bool** | The signature permission to create this object. | [optional] 
**viewTopicContent** | **bool** | The viewTopicContent permission to create this object. | [optional] 
**setSelfAsInvisible** | **bool** | The setSelfAsInvisible permission to create this object. | [optional] 
**editOwnImages** | **bool** | The editOwnImages permission to create this object. | [optional] 
**requirePostApproval** | **bool** | The requirePostApproval permission to create this object. | [optional] 
**viewCalendar** | **bool** | The viewCalendar permission to create this object. | [optional] 
**moderateAlbums** | **bool** | The moderateAlbums permission to create this object. | [optional] 
**editOwnPosts** | **bool** | The editOwnPosts permission to create this object. | [optional] 
**postEvents** | **bool** | The postEvents permission to create this object. | [optional] 
**viewCategory** | **bool** | The viewCategory permission to create this object. | [optional] 
**viewProfiles** | **bool** | The viewProfiles permission to create this object. | [optional] 
**editOwnEvents** | **bool** | The editOwnEvents permission to create this object. | [optional] 
**replyOwnTopics** | **bool** | The replyOwnTopics permission to create this object. | [optional] 
**viewOthersEvents** | **bool** | The viewOthersEvents permission to create this object. | [optional] 
**replyTopics** | **bool** | The replyTopics permission to create this object. | [optional] 
**deleteOwnPosts** | **bool** | The deleteOwnPosts permission to create this object. | [optional] 
**deleteOwnEvents** | **bool** | The deleteOwnEvents permission to create this object. | [optional] 
**deleteOwnImages** | **bool** | The deleteOwnImages permission to create this object. | [optional] 
**deleteOwnProfile** | **bool** | The deleteOwnProfile permission to create this object. | [optional] 
**requireEventApproval** | **bool** | The requireEventApproval permission to create this object. | [optional] 
**postPolls** | **bool** | Boolean representing whether postPolls permission is enabled or not. | [optional] 
**voteOnPolls** | **bool** | Boolean representing whether voteOnPolls permission is enabled or not. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


