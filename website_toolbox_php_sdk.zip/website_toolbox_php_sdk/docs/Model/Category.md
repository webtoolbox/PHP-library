# Category

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**categoryId** | **int** | The unique identifier for a category. | [optional] 
**description** | **string** | An arbitrary string which you can attach to a category object. It is displayed alongside the category in the web interface. | [optional] 
**unlisted** | **bool** | Boolean representing whether a category is unlisted or not. Unlisted will hide it on the category listing on forum. | [optional] 
**title** | **string** | This is the name of the category. It describes the theme of the discussions within the category in a concise manner. | [optional] 
**locked** | **bool** | Boolean representing whether a category is locked or not. Locked will prevent any new posts from being made in the category. | [optional] 
**passwordProtected** | **bool** | Boolean representing whether a category is password protected or not. It is used to password protect the category so only people with the correct password can enter. | [optional] 
**linked** | **string** | The category will not be a real category. Instead it will simply be a link to the URL you provide. | [optional] 
**parentId** | **int** | The categoryId of parent category. | [optional] 
**object** | **string** | String representing the object’s type. Objects of the same type share the same value. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


