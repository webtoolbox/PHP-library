# Conversation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**object** | **string** | String representing the object’s type. Objects of the same type share the same value. | [optional] 
**subject** | **string** | Thing that is being discussed, described for conversation. | [optional] 
**dateTimestamp** | **int** | Time at which the object was created. Measured in seconds since the Unix epoch. | [optional] 
**participants** | [**\Websitetoolbox\Model\ConversationParticipants[]**](ConversationParticipants.md) |  | [optional] 
**conversationId** | **int** | The unique identifier for a conversation. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


