# ConversationParticipants

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**userId** | **int** | Participant&#39;s userId. | [optional] 
**avatarUrl** | **string** | The URL of an icon or image representing a particular person in forum. | [optional] 
**active** | **bool** | Boolean representing whether a participant is active or not. | [optional] 
**username** | **string** | Participant&#39;s username. | [optional] 
**unreadCount** | **int** | The number of unread messages in conversation. | [optional] 
**isStarter** | **bool** | Boolean representing whether a participant is started the conversation or not. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


