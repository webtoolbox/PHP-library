# ErrorError

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**param** | **string** | The parameter the error relates to if the error is parameter-specific. | [optional] 
**message** | **string** | A human-readable message providing more details about the error. | [optional] 
**code** | **string** | A short string related to error. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


