# ListMessagesData

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sender** | [**\Websitetoolbox\Model\ListMessagesSender**](ListMessagesSender.md) |  | [optional] 
**message** | **string** | Message is usually a content, and its purpose is either to ask a question, answer a question or to contributes towards the forum discussion by expressing an opinion or bringing forth information. | [optional] 
**messageId** | **int** | The unique identifier for a message. | [optional] 
**attachments** | [**\Websitetoolbox\Model\MessageAttachments[]**](MessageAttachments.md) |  | [optional] 
**dateTimestamp** | **int** | Time at which the object was created. Measured in seconds since the Unix epoch. | [optional] 
**object** | **string** | String representing the object’s type. Objects of the same type share the same value. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


