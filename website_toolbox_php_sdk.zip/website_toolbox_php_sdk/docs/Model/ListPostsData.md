# ListPostsData

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**message** | **string** | Message is usually a content, and its purpose is either to ask a question, answer a question or to contributes towards the forum discussion by expressing an opinion or bringing forth information. | [optional] 
**likeCount** | **int** | Total number of post likes. | [optional] 
**postTimestamp** | **int** | Time at which the object was created. Measured in seconds since the Unix epoch. | [optional] 
**postId** | **int** | The unique identifier of post | [optional] 
**dislikeCount** | **int** | Total number of post dislikes. | [optional] 
**author** | [**\Websitetoolbox\Model\PostAuthor**](PostAuthor.md) |  | [optional] 
**attachments** | [**\Websitetoolbox\Model\PostAttachments[]**](PostAttachments.md) |  | [optional] 
**attachmentCount** | **int** | Total number of attachments in post. | [optional] 
**pending** | **bool** | Boolean representing whether a post is pending or not. Pending post will only be displayed after approval of moderator. | [optional] 
**object** | **string** | String representing the object’s type. Objects of the same type share the same value. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


