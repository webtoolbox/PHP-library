# ListTopics

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**object** | **string** |  | [optional] 
**hasMore** | **bool** |  | [optional] 
**url** | **string** |  | [optional] 
**size** | **int** |  | [optional] 
**totalSize** | **int** |  | [optional] 
**data** | [**\Websitetoolbox\Model\ListTopicsData[]**](ListTopicsData.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


