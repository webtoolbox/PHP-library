# ListTopicsData

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**lastPost** | [**\Websitetoolbox\Model\ListTopicsLastPost**](ListTopicsLastPost.md) |  | [optional] 
**viewCount** | **int** | The number of views in topic. | [optional] 
**firstPostId** | **int** | The unique identifier of first post in topic. | [optional] 
**locked** | **bool** | Boolean representing whether a topic is locked or not. Locked will prevent any new posts from being made in the topic. | [optional] 
**postCount** | **int** | The number of posts in topic. | [optional] 
**replyCount** | **int** | The number of replies in topic. | [optional] 
**pinned** | **bool** | Boolean representing whether a topic is pinned or not. Pinned topic display at the beginning of that forum&#39;s topic listing to ensure that it receives attention from forum users. | [optional] 
**topicId** | **int** | The unique identifier for a topic. | [optional] 
**title** | **string** | Thing that is being discussed, described for topic. | [optional] 
**author** | [**\Websitetoolbox\Model\ListTopicsAuthor**](ListTopicsAuthor.md) |  | [optional] 
**categoryId** | **int** | The unique identifier of category that belongs to this object. | [optional] 
**dateTimestamp** | **int** | Time at which the object was created. Measured in seconds since the Unix epoch. | [optional] 
**object** | **string** | String representing the object’s type. Objects of the same type share the same value. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


