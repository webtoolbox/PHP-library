# ListTopicsLastPostAuthor

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**avatarUrl** | **string** | The URL of an icon or image representing a particular member in forum who created last post. | [optional] 
**userId** | **int** | The userId of member who created last post. | [optional] 
**username** | **string** | The username of member who created last post. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


