# MessageAttachments

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**fileName** | **string** | The file name of attachment. | [optional] 
**uRL** | **string** | The attachment URL. | [optional] 
**id** | **string** | The unique identifier for a attachment. | [optional] 
**object** | **string** | String representing the object’s type. Objects of the same type share the same value. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


