# PostAttachments

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**fileName** | **string** | The file name of attachment. | [optional] 
**uRL** | **string** | The attachment URL. | [optional] 
**id** | **string** | The unique identifier for a attachment. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


