# TopicLastPost

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**author** | [**\Websitetoolbox\Model\ListTopicsLastPostAuthor**](ListTopicsLastPostAuthor.md) |  | [optional] 
**timestamp** | **int** | Time at which the last post was created. Measured in seconds since the Unix epoch. | [optional] 
**postId** | **int** | The unique identifier for a post. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


