# UpdateUser

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**username** | **string** | The username of member. | [optional] 
**password** | **string** | The password of member. | [optional] 
**email** | **string** | The email address of the member. | [optional] 
**userGroups** | **int[]** | A list of user groups that belongs to this member. | [optional] 
**signature** | **string** | Signature of member. | [optional] 
**name** | **string** | The name of member. | [optional] 
**instantMessagingType** | **string** | Instant messaging type of the member. | [optional] 
**lastPostTimestamp** | **int** | Instant messaging type of member. | [optional] 
**instantMessagingId** | **string** | Instant messaging id of member. | [optional] 
**birthday** | **string** | Birthday of the member. | [optional] 
**customFields** | [**\Websitetoolbox\Model\AddUserCustomFields[]**](AddUserCustomFields.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


