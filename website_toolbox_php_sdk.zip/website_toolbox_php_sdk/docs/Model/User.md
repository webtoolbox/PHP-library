# User

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**userId** | **int** | The unique identifier of member that belongs to this object. | [optional] 
**allowEmails** | **bool** | Boolean representing whether a member allow other members to send emails or not. | [optional] 
**userTitle** | **string** | The title of member. | [optional] 
**avatarUrl** | **string** | The URL of an icon or image representing the member in forum who created this object. | [optional] 
**reputation** | **int** | It is a reputation score of member based on how much the community has liked their posts. The number of likes minus the number of dislikes a member&#39;s posts receive becomes their reputation score. | [optional] 
**userGroups** | **int[]** | A list of user groups that belongs to this member. | [optional] 
**instantMessagingType** | **string** | Instant messaging type of member. | [optional] 
**joinDateTimestamp** | **int** | Time at which the member was created. Measured in seconds since the Unix epoch. | [optional] 
**lastPostTimestamp** | **int** | Time at which the member was created last post. Measured in seconds since the Unix epoch. | [optional] 
**name** | **string** | The name of member. | [optional] 
**invisible** | **bool** | Boolean representing whether a member is invisible or not. Invisible member browse the forum without other users knowing you are online. | [optional] 
**enableMessages** | **bool** | Boolean representing whether a member has permission to send messages or not. | [optional] 
**username** | **string** | The username of member. | [optional] 
**postCount** | **int** | The number of posts created by member. | [optional] 
**signature** | **string** | Signature of member. | [optional] 
**email** | **string** | The email address of the member. | [optional] 
**object** | **string** | String representing the object’s type. Objects of the same type share the same value. | [optional] 
**lastVisitTimestamp** | **int** | Time at which the member was last visited. Measured in seconds since the Unix epoch. | [optional] 
**customFields** | [**\Websitetoolbox\Model\UserCustomFields[]**](UserCustomFields.md) | A list of custom fields belongs to member. | [optional] 
**instantMessagingId** | **string** | Instant messaging id of member. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


