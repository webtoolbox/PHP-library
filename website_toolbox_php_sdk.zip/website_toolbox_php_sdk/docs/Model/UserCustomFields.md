# UserCustomFields

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**object** | **string** | String representing the object’s type. Objects of the same type share the same value. | [optional] 
**profileFieldId** | **int** | The unique identifier of custom field that belongs to this object. | [optional] 
**title** | **string** | The title of custom field. | [optional] 
**type** | **string** | The type of custom field. | [optional] 
**value** | **string** | The value of custom field. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


