# Usergroup

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**userGroupId** | **int** | The unique identifier for a user group. | [optional] 
**title** | **string** | This is the name of user group. It is not shown to members but used to identify in User Group Manager. | [optional] 
**object** | **string** | String representing the object’s type. Objects of the same type share the same value. | [optional] 
**requireEventApproval** | **bool** | Boolean representing whether requireEventApproval permission is enabled or not. | [optional] 
**viewInvisibleMembers** | **bool** | Boolean representing whether viewInvisibleMembers permission is enabled or not. | [optional] 
**viewOthersTopics** | **bool** | Boolean representing whether viewOthersTopics permission is enabled or not. | [optional] 
**viewableOnMembersList** | **bool** | Boolean representing whether viewableOnMembersList permission is enabled or not. | [optional] 
**uploadAttachments** | **bool** | Boolean representing whether uploadAttachments permission is enabled or not. | [optional] 
**changeUsername** | **bool** | Boolean representing whether changeUsername permission is enabled or not. | [optional] 
**defaultGroup** | **bool** | Boolean representing whether defaultGroup permission is enabled or not. | [optional] 
**viewForum** | **bool** | Boolean representing whether viewForum permission is enabled or not. | [optional] 
**startTopics** | **bool** | Boolean representing whether startTopics permission is enabled or not. | [optional] 
**deleteOwnTopics** | **bool** | Boolean representing whether deleteOwnTopics permission is enabled or not. | [optional] 
**createAlbums** | **bool** | Boolean representing whether createAlbums permission is enabled or not. | [optional] 
**moveOwnTopics** | **bool** | Boolean representing whether moveOwnTopics permission is enabled or not. | [optional] 
**viewAttachments** | **bool** | Boolean representing whether viewAttachments permission is enabled or not. | [optional] 
**editOwnProfile** | **bool** | Boolean representing whether editOwnProfile permission is enabled or not. | [optional] 
**customTitle** | **bool** | Boolean representing whether customTitle permission is enabled or not. | [optional] 
**viewAlbums** | **bool** | Boolean representing whether viewAlbums permission is enabled or not. | [optional] 
**signature** | **bool** | Boolean representing whether signature permission is enabled or not. | [optional] 
**viewTopicContent** | **bool** | Boolean representing whether viewTopicContent permission is enabled or not. | [optional] 
**setSelfAsInvisible** | **bool** | Boolean representing whether setSelfAsInvisible permission is enabled or not. | [optional] 
**editOwnImages** | **bool** | Boolean representing whether editOwnImages permission is enabled or not. | [optional] 
**requirePostApproval** | **bool** | Boolean representing whether requirePostApproval permission is enabled or not. | [optional] 
**viewCalendar** | **bool** | Boolean representing whether viewCalendar permission is enabled or not. | [optional] 
**moderateAlbums** | **bool** | Boolean representing whether moderateAlbums permission is enabled or not. | [optional] 
**editOwnPosts** | **bool** | Boolean representing whether editOwnPosts permission is enabled or not. | [optional] 
**postEvents** | **bool** | Boolean representing whether postEvents permission is enabled or not. | [optional] 
**viewCategory** | **bool** | Boolean representing whether viewCategory permission is enabled or not. | [optional] 
**viewProfiles** | **bool** | Boolean representing whether viewProfiles permission is enabled or not. | [optional] 
**editOwnEvents** | **bool** | Boolean representing whether editOwnEvents permission is enabled or not. | [optional] 
**replyOwnTopics** | **bool** | Boolean representing whether replyOwnTopics permission is enabled or not. | [optional] 
**viewOthersEvents** | **bool** | Boolean representing whether viewOthersEvents permission is enabled or not. | [optional] 
**replyTopics** | **bool** | Boolean representing whether replyTopics permission is enabled or not. | [optional] 
**deleteOwnPosts** | **bool** | Boolean representing whether deleteOwnPosts permission is enabled or not. | [optional] 
**deleteOwnEvents** | **bool** | Boolean representing whether deleteOwnEvents permission is enabled or not. | [optional] 
**deleteOwnImages** | **bool** | Boolean representing whether deleteOwnImages permission is enabled or not. | [optional] 
**deleteOwnProfile** | **bool** | Boolean representing whether deleteOwnProfile permission is enabled or not. | [optional] 
**postPolls** | **bool** | Boolean representing whether postPolls permission is enabled or not. | [optional] 
**voteOnPolls** | **bool** | Boolean representing whether voteOnPolls permission is enabled or not. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


