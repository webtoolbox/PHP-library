<?php
require_once('../autoload.php');

$api_instance = new Websitetoolbox\Api\CategoriesApi();
$xApiKey = "API_KEY"; // string |

try {
    $result = $api_instance->getCategories($xApiKey);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling CategoriesApi->getCategories: ', $e->getMessage(), PHP_EOL;
}

?>

