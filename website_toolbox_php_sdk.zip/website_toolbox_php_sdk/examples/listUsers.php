<?php
require_once('../autoload.php');

$api_instance = new Websitetoolbox\Api\UsersApi();
$xApiKey = "API_KEY"; // string |

try {
    $result = $api_instance->getUsers($xApiKey);
    var_dump($result);
} catch (Exception $e) {
    echo 'Exception when calling CategoriesApi->getCategories: ', $e->getMessage(), PHP_EOL;
}

?>

